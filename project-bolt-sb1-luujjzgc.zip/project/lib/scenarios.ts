export interface GKScenario {
  id: number;
  half: 'First Half' | 'Second Half';
  time: string;
  score: string;
  situation: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  metric: 'Patience' | 'Reading the Shooter' | 'Pressure Control';
}

export const GK_SCENARIOS: GKScenario[] = [
  {
    id: 1,
    half: 'First Half',
    time: '24:13',
    score: '11–10',
    situation:
      'The opponent attacks six against six. The right back has already scored twice with a high shot toward your left side. The defender is late and the shooter has space for a full jump shot.',
    question: 'What should be your primary focus?',
    options: [
      'Move early toward the left upper corner.',
      'Stay patient and read the shooter\'s arm and body position.',
      'Step aggressively to the six-metre line before the jump.',
      'Ignore the shooter and focus mainly on the pivot.',
    ],
    correctIndex: 1,
    explanation:
      'Moving early gives the shooter time to change the shot. Staying patient allows the goalkeeper to read the final arm and body position.',
    metric: 'Reading the Shooter',
  },
  {
    id: 2,
    half: 'Second Half',
    time: '42:36',
    score: '20–19',
    situation:
      'Left wing receives the ball at a very narrow angle. He previously scored once at the near post and once with a lob.',
    question: 'What should you prioritize?',
    options: [
      'Stand completely still on the goal line.',
      'Close the near post while staying balanced for the lob.',
      'Run directly toward the shooter.',
      'Move early toward the far post.',
    ],
    correctIndex: 1,
    explanation:
      'The wing has shown two different finishes. Closing the near post while staying balanced covers the most likely angle and keeps you ready for the lob.',
    metric: 'Reading the Shooter',
  },
  {
    id: 3,
    half: 'Second Half',
    time: '51:08',
    score: '25–25',
    situation:
      'Fast break. The attacker approaches alone from the centre and still has several metres before the six-metre line.',
    question: 'What is the best initial response?',
    options: [
      'Stay deep inside the goal.',
      'Rush forward immediately without controlling your position.',
      'Advance under control, stay large and react late.',
      'Turn sideways before the attacker shoots.',
    ],
    correctIndex: 2,
    explanation:
      'Advancing under control narrows the angle without committing. Staying large and reacting late forces the attacker to make the first decision.',
    metric: 'Patience',
  },
  {
    id: 4,
    half: 'Second Half',
    time: '56:41',
    score: '28–27',
    situation:
      'Seven-metre throw. The shooter previously used two low shots, but is now looking at the goalkeeper for a long time.',
    question: 'What is the best mental and tactical approach?',
    options: [
      'Choose a corner before the whistle and move early.',
      'Focus only on the previous two shots.',
      'Stay calm, hold your position and react to the final movement.',
      'Turn your back to reduce pressure.',
    ],
    correctIndex: 2,
    explanation:
      'Previous shots are information, not certainty. Holding position and reacting to the final movement keeps every corner live.',
    metric: 'Pressure Control',
  },
  {
    id: 5,
    half: 'Second Half',
    time: '59:18',
    score: '30–30',
    situation:
      'The opponent plays seven against six. The pivot receives the ball under pressure at six metres, slightly off balance.',
    question: 'What should be your main focus?',
    options: [
      'Drop early before the pivot controls the ball.',
      'Stay upright, read the release and react late.',
      'Move toward the wing before the pivot shoots.',
      'Leave the goal and attack the pivot.',
    ],
    correctIndex: 1,
    explanation:
      'The pivot is off balance, so the release will be slower. Staying upright and reacting late gives you the best chance to cover the finish.',
    metric: 'Pressure Control',
  },
];

export const SESSION_INFO = {
  title: 'Reading the Shooter',
  subtitle: 'Goalkeeper IQ',
  sessionNumber: 'Session 01',
  description:
    'You will analyze five realistic match situations and choose the best goalkeeper response.',
  structure: ['5 match scenarios', 'approximately 10 minutes', 'feedback after completion'],
  instruction:
    'Do not guess quickly. Read the score, match time, attacker position and previous shooting behavior.',
  duration: '10 min',
  difficulty: 'Intermediate',
};

export const SESSION_RESULTS = {
  strengths: [
    'Good recognition of shooting patterns',
    'Strong positioning in wing situations',
    'Calm decision-making during fast breaks',
  ],
  improve: [
    'Avoid committing too early',
    'Use previous shots as information, not as certainty',
    'Stay balanced under pressure',
  ],
  recommendation:
    'Repeat this session in 48 hours and focus on delaying your first movement.',
};

export function getMetricRating(metric: string, correctCount: number, total: number): string {
  const ratio = total > 0 ? correctCount / total : 0;
  if (ratio >= 0.8) return 'Strong';
  if (ratio >= 0.6) return 'Good';
  return 'Developing';
}
