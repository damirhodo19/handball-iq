import { useState } from 'react';
import { View, StyleSheet, Text, ScrollView, TextInput, TouchableOpacity } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react-native';
import { Colors, Spacing, Radius } from '@/lib/theme';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { ScreenBackground } from '@/components/Screen';
import { useMatchDay } from '@/context/MatchDayContext';
import { MatchType, MatchLocation, PlayingTime, PersonalGoal, PrepMode } from '@/lib/match-day-storage';
import { getMatchDayPersonalGoals, HandballPosition } from '@/lib/positions';
import { loadProfile } from '@/lib/storage';

const MATCH_TYPES: MatchType[] = ['League', 'Cup', 'Friendly', 'Tournament'];
const LOCATIONS: MatchLocation[] = ['Home', 'Away', 'Neutral'];
const PLAYING_TIMES: PlayingTime[] = ['Starter', 'Shared minutes', 'Substitute'];

// Use string[] instead of PersonalGoal[] since position-specific goals are dynamic
const POSITION_GOALS = getMatchDayPersonalGoals('Goalkeeper');

export default function SetupScreen() {
  const { mode = 'complete' } = useLocalSearchParams<{ mode?: PrepMode }>();
  const { startPrep } = useMatchDay();

  const [opponent, setOpponent] = useState('');
  const [matchType, setMatchType] = useState<MatchType>('League');
  const [location, setLocation] = useState<MatchLocation>('Home');
  const [playingTime, setPlayingTime] = useState<PlayingTime>('Starter');
  const [goals, setGoals] = useState<string[]>([]);
  const [opponentError, setOpponentError] = useState(false);

  // Load position-specific goals on mount
  const profile = loadProfile();
  const position = (profile.position as HandballPosition) || 'Goalkeeper';
  const PERSONAL_GOALS = getMatchDayPersonalGoals(position);

  const toggleGoal = (g: string) => {
    setGoals((prev) => {
      if (prev.includes(g)) return prev.filter((x) => x !== g);
      if (prev.length >= 2) return prev;
      return [...prev, g];
    });
  };

  const handleStart = () => {
    if (!opponent.trim()) { setOpponentError(true); return; }
    if (goals.length === 0) return;
    setOpponentError(false);
    const prep = startPrep(mode as PrepMode, { opponent: opponent.trim(), matchType, location, playingTime, goals: goals as PersonalGoal[] });
    router.replace('/match-day/prepare');
  };

  return (
    <ScreenBackground>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">

        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <ArrowLeft size={20} color={Colors.gold} />
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>Match Setup</Text>
            <Text style={styles.headerSub}>{mode === 'quick' ? 'Quick Preparation · 5 min' : 'Complete Preparation · 10 min'}</Text>
          </View>
        </View>

        {/* Opponent */}
        <Animated.View entering={FadeInDown.delay(50).duration(400)}>
          <Text style={styles.label}>Opponent Name</Text>
          <TextInput
            style={[styles.textInput, opponentError && styles.textInputError]}
            placeholder="e.g. Berlin Lions"
            placeholderTextColor={Colors.textQuaternary}
            value={opponent}
            onChangeText={(t) => { setOpponent(t); setOpponentError(false); }}
            returnKeyType="done"
          />
          {opponentError && <Text style={styles.errorText}>Please enter an opponent name.</Text>}
        </Animated.View>

        {/* Match Type */}
        <Animated.View entering={FadeInDown.delay(100).duration(400)}>
          <Text style={styles.label}>Match Type</Text>
          <View style={styles.chipRow}>
            {MATCH_TYPES.map((t) => (
              <TouchableOpacity
                key={t}
                style={[styles.chip, matchType === t && styles.chipActive]}
                onPress={() => setMatchType(t)}
                activeOpacity={0.8}
              >
                {matchType === t && <Check size={12} color={Colors.background} />}
                <Text style={[styles.chipText, matchType === t && styles.chipTextActive]}>{t}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Animated.View>

        {/* Location */}
        <Animated.View entering={FadeInDown.delay(150).duration(400)}>
          <Text style={styles.label}>Match Location</Text>
          <View style={styles.chipRow}>
            {LOCATIONS.map((l) => (
              <TouchableOpacity
                key={l}
                style={[styles.chip, location === l && styles.chipActive]}
                onPress={() => setLocation(l)}
                activeOpacity={0.8}
              >
                {location === l && <Check size={12} color={Colors.background} />}
                <Text style={[styles.chipText, location === l && styles.chipTextActive]}>{l}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Animated.View>

        {/* Playing Time */}
        <Animated.View entering={FadeInDown.delay(200).duration(400)}>
          <Text style={styles.label}>Expected Playing Time</Text>
          <View style={styles.chipRow}>
            {PLAYING_TIMES.map((pt) => (
              <TouchableOpacity
                key={pt}
                style={[styles.chip, playingTime === pt && styles.chipActive]}
                onPress={() => setPlayingTime(pt)}
                activeOpacity={0.8}
              >
                {playingTime === pt && <Check size={12} color={Colors.background} />}
                <Text style={[styles.chipText, playingTime === pt && styles.chipTextActive]}>{pt}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Animated.View>

        {/* Personal Goals */}
        <Animated.View entering={FadeInDown.delay(250).duration(400)}>
          <Text style={styles.label}>Main Personal Goal <Text style={styles.labelMuted}>(choose 1 or 2)</Text></Text>
          <View style={styles.goalGrid}>
            {PERSONAL_GOALS.map((g) => {
              const active = goals.includes(g);
              const disabled = !active && goals.length >= 2;
              return (
                <TouchableOpacity
                  key={g}
                  style={[styles.goalChip, active && styles.goalChipActive, disabled && styles.goalChipDisabled]}
                  onPress={() => !disabled && toggleGoal(g)}
                  activeOpacity={0.8}
                >
                  {active && <Check size={13} color={Colors.background} />}
                  <Text style={[styles.goalText, active && styles.goalTextActive, disabled && styles.goalTextDisabled]}>{g}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
          {goals.length === 0 && (
            <Text style={styles.errorText}>Select at least one goal to continue.</Text>
          )}
        </Animated.View>

        {/* Start */}
        <Animated.View entering={FadeInDown.delay(300).duration(400)} style={styles.btnWrap}>
          <Button
            label="Begin Preparation"
            onPress={handleStart}
            disabled={goals.length === 0 || !opponent.trim()}
            iconRight={<ArrowRight size={20} color={Colors.background} />}
          />
        </Animated.View>
      </ScrollView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.xxxl + 16, paddingBottom: Spacing.xxxl },

  header: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, marginBottom: Spacing.xl },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.goldSoft, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontFamily: 'Inter-ExtraBold', fontSize: 22, color: Colors.textPrimary },
  headerSub: { color: Colors.gold, fontFamily: 'Inter-SemiBold', fontSize: 13, marginTop: 2 },

  label: { fontFamily: 'Inter-SemiBold', fontSize: 13, color: Colors.textSecondary, letterSpacing: 0.5, marginBottom: Spacing.sm, marginTop: Spacing.lg },
  labelMuted: { color: Colors.textQuaternary, fontFamily: 'Inter-Regular' },
  errorText: { color: Colors.error, fontFamily: 'Inter-Regular', fontSize: 12, marginTop: Spacing.xs },

  textInput: {
    backgroundColor: Colors.surfaceRaised,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.border,
    color: Colors.textPrimary,
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    paddingHorizontal: Spacing.md,
    paddingVertical: 14,
  },
  textInputError: { borderColor: Colors.error },

  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 14, paddingVertical: 10, borderRadius: Radius.pill, backgroundColor: Colors.surfaceRaised, borderWidth: 1.5, borderColor: Colors.border },
  chipActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  chipText: { fontFamily: 'Inter-SemiBold', fontSize: 14, color: Colors.textSecondary },
  chipTextActive: { color: Colors.background },

  goalGrid: { gap: Spacing.sm },
  goalChip: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingHorizontal: Spacing.md, paddingVertical: 13, borderRadius: Radius.md, backgroundColor: Colors.surfaceRaised, borderWidth: 1.5, borderColor: Colors.border },
  goalChipActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  goalChipDisabled: { opacity: 0.35 },
  goalText: { fontFamily: 'Inter-SemiBold', fontSize: 15, color: Colors.textPrimary },
  goalTextActive: { color: Colors.background },
  goalTextDisabled: { color: Colors.textQuaternary },

  btnWrap: { marginTop: Spacing.xxl },
});
