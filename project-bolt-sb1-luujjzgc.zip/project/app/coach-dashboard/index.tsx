import { useState, useCallback } from 'react';
import { View, StyleSheet, Text, ScrollView, TouchableOpacity } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import {
  ArrowLeft, Users, Activity, Target, Brain, TrendingUp, TrendingDown,
  ChevronRight, Calendar, ClipboardList, BarChart3, Bell, UserCircle, Shield,
} from 'lucide-react-native';
import { Colors, Spacing, Radius } from '@/lib/theme';
import { Card, PressableCard } from '@/components/Card';
import { ScreenBackground, ProgressBar } from '@/components/Screen';
import { loadCoachAccount, getTeamStats, TeamStats, generateTeamRecommendations, TrainingRecommendation } from '@/lib/coach-dashboard-data';

export default function CoachDashboardHome() {
  const [stats, setStats] = useState<TeamStats | null>(null);
  const [coach, setCoach] = useState(loadCoachAccount());
  const [topRecs, setTopRecs] = useState<TrainingRecommendation[]>([]);

  useFocusEffect(useCallback(() => {
    setStats(getTeamStats());
    setCoach(loadCoachAccount());
    setTopRecs(generateTeamRecommendations().slice(0, 3));
  }, []));

  if (!coach) {
    return (
      <ScreenBackground>
        <View style={styles.centered}>
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </ScreenBackground>
    );
  }

  const weeklyProgressColor = (stats?.weeklyProgress ?? 0) >= 0 ? Colors.success : Colors.error;

  return (
    <ScreenBackground>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Header */}
        <Animated.View entering={FadeIn.duration(400)} style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <ArrowLeft size={20} color={Colors.gold} />
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>{coach.teamName}</Text>
            <Text style={styles.headerSub}>{coach.role} · {coach.name}</Text>
          </View>
          <View style={styles.headerIcon}><Shield size={20} color={Colors.gold} /></View>
        </Animated.View>

        {/* Stats Grid */}
        {stats && (
          <Animated.View entering={FadeInDown.delay(50).duration(500)}>
            <Text style={styles.sectionLabel}>TEAM OVERVIEW</Text>
            <View style={styles.statsGrid}>
              <StatCard icon={<Users size={18} color={Colors.gold} />} value={`${stats.totalPlayers}`} label="Total Players" />
              <StatCard icon={<Activity size={18} color={Colors.success} />} value={`${stats.todayActive}`} label="Active Today" />
              <StatCard icon={<Target size={18} color={Colors.info} />} value={`${stats.sessionsCompleted}`} label="Sessions Done" />
              <StatCard icon={<Brain size={18} color={Colors.gold} />} value={`${stats.avgDecisionScore}`} label="Avg Decision" />
            </View>
          </Animated.View>
        )}

        {/* Mental Readiness + Weekly Progress */}
        {stats && (
          <Animated.View entering={FadeInDown.delay(100).duration(500)}>
            <Card variant="gradient" shadow="card" style={styles.progressCard}>
              <View style={styles.progressRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.progressLabel}>Average Mental Readiness</Text>
                  <Text style={styles.progressValue}>{stats.avgMentalReadiness}%</Text>
                </View>
                <View style={styles.progressIconWrap}><Brain size={22} color={Colors.gold} /></View>
              </View>
              <ProgressBar progress={stats.avgMentalReadiness / 100} height={5} color={Colors.gold} />
            </Card>

            <Card variant="gradient" shadow="card" style={styles.progressCard}>
              <View style={styles.progressRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.progressLabel}>Weekly Progress</Text>
                  <Text style={[styles.progressValue, { color: weeklyProgressColor }]}>
                    {stats.weeklyProgress > 0 ? '+' : ''}{stats.weeklyProgress} pts
                  </Text>
                </View>
                <View style={styles.progressIconWrap}>
                  {stats.weeklyProgress >= 0 ? <TrendingUp size={22} color={Colors.success} /> : <TrendingDown size={22} color={Colors.error} />}
                </View>
              </View>
            </Card>
          </Animated.View>
        )}

        {/* Top Recommendations */}
        {topRecs.length > 0 && (
          <Animated.View entering={FadeInDown.delay(150).duration(500)}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionLabel}>PRIORITY RECOMMENDATIONS</Text>
              <TouchableOpacity onPress={() => router.push('/coach-dashboard/team-analysis')}>
                <Text style={styles.seeAllText}>See all</Text>
              </TouchableOpacity>
            </View>
            {topRecs.map((rec, i) => (
              <Card key={i} variant="gradient" shadow="card" style={styles.recCard}>
                <View style={styles.recHeader}>
                  <View style={[styles.severityDot, { backgroundColor: rec.severity === 'high' ? Colors.error : rec.severity === 'medium' ? Colors.warning : Colors.success }]} />
                  <Text style={styles.recPlayer}>{rec.playerName}</Text>
                </View>
                <Text style={styles.recIssue}>{rec.issue}</Text>
                <Text style={styles.recAction}>{rec.recommendation}</Text>
              </Card>
            ))}
          </Animated.View>
        )}

        {/* Menu */}
        <Animated.View entering={FadeInDown.delay(200).duration(500)}>
          <Text style={styles.sectionLabel}>MANAGEMENT</Text>
          <View style={styles.menuCol}>
            <MenuItem icon={<Users size={20} color={Colors.gold} />} title="Player List" subtitle="View all players and their reports" onPress={() => router.push('/coach-dashboard/players')} />
            <MenuItem icon={<BarChart3 size={20} color={Colors.gold} />} title="Team Analysis" subtitle="Team strengths, weaknesses and attention areas" onPress={() => router.push('/coach-dashboard/team-analysis')} />
            <MenuItem icon={<ClipboardList size={20} color={Colors.gold} />} title="Session Assignment" subtitle="Assign training sessions to players" onPress={() => router.push('/coach-dashboard/assign')} />
            <MenuItem icon={<UserCircle size={20} color={Colors.gold} />} title="Player Comparison" subtitle="Compare two players side by side" onPress={() => router.push('/coach-dashboard/compare')} />
            <MenuItem icon={<Bell size={20} color={Colors.gold} />} title="Notifications" subtitle="Send messages to your players" onPress={() => router.push('/coach-dashboard/notifications')} />
            <MenuItem icon={<Calendar size={20} color={Colors.gold} />} title="Team Calendar" subtitle="Training, matches and assigned sessions" onPress={() => router.push('/coach-dashboard/calendar')} />
          </View>
        </Animated.View>
      </ScrollView>
    </ScreenBackground>
  );
}

function StatCard({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <View style={styles.statCard}>
      <View style={styles.statIcon}>{icon}</View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function MenuItem({ icon, title, subtitle, onPress }: { icon: React.ReactNode; title: string; subtitle: string; onPress: () => void }) {
  return (
    <PressableCard onPress={onPress} variant="gradient" shadow="card" style={styles.menuCard}>
      <View style={styles.menuRow}>
        <View style={styles.menuIcon}>{icon}</View>
        <View style={{ flex: 1, gap: 2 }}>
          <Text style={styles.menuTitle}>{title}</Text>
          <Text style={styles.menuSub}>{subtitle}</Text>
        </View>
        <ChevronRight size={18} color={Colors.gold} />
      </View>
    </PressableCard>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.xxxl + 16, paddingBottom: Spacing.xxxl },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: Colors.textTertiary, fontFamily: 'Inter-Regular', fontSize: 16 },

  header: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, marginBottom: Spacing.lg },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.goldSoft, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontFamily: 'Inter-ExtraBold', fontSize: 22, color: Colors.textPrimary },
  headerSub: { color: Colors.gold, fontFamily: 'Inter-SemiBold', fontSize: 13, marginTop: 2 },
  headerIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.goldSoft, borderWidth: 1, borderColor: Colors.gold, justifyContent: 'center', alignItems: 'center' },

  sectionLabel: { color: Colors.textTertiary, fontFamily: 'Inter-SemiBold', fontSize: 11, letterSpacing: 1.5, marginBottom: Spacing.sm, marginTop: Spacing.lg },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  seeAllText: { color: Colors.gold, fontFamily: 'Inter-SemiBold', fontSize: 13 },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  statCard: { width: '48%', backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.md, gap: 6, borderWidth: 1, borderColor: Colors.border },
  statIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: Colors.goldSoft, justifyContent: 'center', alignItems: 'center' },
  statValue: { fontFamily: 'Inter-ExtraBold', fontSize: 24, color: Colors.textPrimary },
  statLabel: { fontFamily: 'Inter-SemiBold', fontSize: 11, color: Colors.textTertiary, letterSpacing: 0.5 },

  progressCard: { gap: Spacing.sm, marginBottom: Spacing.sm },
  progressRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  progressLabel: { fontFamily: 'Inter-SemiBold', fontSize: 13, color: Colors.textTertiary },
  progressValue: { fontFamily: 'Inter-ExtraBold', fontSize: 26, color: Colors.textPrimary, marginTop: 2 },
  progressIconWrap: { width: 44, height: 44, borderRadius: 14, backgroundColor: Colors.goldSoft, justifyContent: 'center', alignItems: 'center' },

  recCard: { gap: Spacing.xs, marginBottom: Spacing.sm },
  recHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  severityDot: { width: 8, height: 8, borderRadius: 4 },
  recPlayer: { fontFamily: 'Inter-ExtraBold', fontSize: 14, color: Colors.textPrimary },
  recIssue: { color: Colors.textSecondary, fontFamily: 'Inter-Regular', fontSize: 13, lineHeight: 19 },
  recAction: { color: Colors.gold, fontFamily: 'Inter-SemiBold', fontSize: 13, lineHeight: 19 },

  menuCol: { gap: Spacing.sm },
  menuCard: { marginBottom: 0 },
  menuRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  menuIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: Colors.goldSoft, justifyContent: 'center', alignItems: 'center' },
  menuTitle: { fontFamily: 'Inter-ExtraBold', fontSize: 16, color: Colors.textPrimary },
  menuSub: { fontFamily: 'Inter-Regular', fontSize: 13, color: Colors.textTertiary },
});
