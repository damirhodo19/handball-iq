import { useState } from 'react';
import { View, StyleSheet, Text, ScrollView, TextInput, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { X, ClipboardList, ArrowRight, Brain, Target, Shield } from 'lucide-react-native';
import { Colors, Typography, Spacing, Radius } from '@/lib/theme';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { ScreenBackground } from '@/components/Screen';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

const RATING_LABELS = ['Poor', 'Below Avg', 'Average', 'Good', 'Excellent'];

export default function PostMatchReviewScreen() {
  const { refreshProfile } = useAuth();
  const [opponent, setOpponent] = useState('');
  const [matchDate, setMatchDate] = useState(new Date().toISOString().split('T')[0]);
  const [decisionMaking, setDecisionMaking] = useState(3);
  const [focus, setFocus] = useState(3);
  const [confidence, setConfidence] = useState(3);
  const [mistakes, setMistakes] = useState('');
  const [mentalState, setMentalState] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  async function submit() {
    if (!opponent.trim()) { setError('Enter the opponent.'); return; }
    setSaving(true);
    setError(null);
    const { error } = await supabase.from('post_match_reviews').insert({
      opponent: opponent.trim(),
      match_date: matchDate ? new Date(matchDate).toISOString() : new Date().toISOString(),
      decision_making: decisionMaking,
      focus,
      confidence,
      mistakes: mistakes.trim() || null,
      mental_state: mentalState.trim() || null,
      notes: notes.trim() || null,
    });
    setSaving(false);
    if (error) { setError(error.message); return; }
    setSaved(true);
    await refreshProfile();
  }

  if (saved) {
    return (
      <ScreenBackground>
        <View style={styles.savedWrap}>
          <View style={styles.savedIcon}><ClipboardList size={36} color={Colors.background} /></View>
          <Text style={styles.savedTitle}>Review Saved</Text>
          <Text style={styles.savedSub}>Your reflection has been recorded. Use it to sharpen your next performance.</Text>
          <Button label="Back to Match Day" onPress={() => router.replace('/(tabs)/match-day')} />
        </View>
      </ScreenBackground>
    );
  }

  return (
    <ScreenBackground>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeBtn}><X size={22} color={Colors.textSecondary} /></TouchableOpacity>
        <Text style={styles.headerTitle}>Post Match Review</Text>
        <View style={{ width: 22 }} />
      </View>
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <Text style={styles.intro}>Reflect honestly. Honest reflection accelerates growth more than any drill.</Text>

        <Animated.View entering={FadeInDown.delay(100).duration(400)}>
          <Card variant="gradient" shadow="card" style={styles.card}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>OPPONENT</Text>
              <TextInput style={styles.input} placeholder="e.g. THW Kiel" placeholderTextColor={Colors.textQuaternary} value={opponent} onChangeText={setOpponent} />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>MATCH DATE</Text>
              <TextInput style={styles.input} placeholder="YYYY-MM-DD" placeholderTextColor={Colors.textQuaternary} value={matchDate} onChangeText={setMatchDate} />
            </View>
          </Card>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(200).duration(400)}>
          <Card variant="gradient" shadow="card" style={styles.card}>
            <Text style={styles.cardSectionTitle}>PERFORMANCE RATINGS</Text>
            <SliderRow icon={<Brain size={16} color={Colors.gold} />} label="Decision Making" value={decisionMaking} onChange={setDecisionMaking} />
            <SliderRow icon={<Target size={16} color={Colors.gold} />} label="Focus" value={focus} onChange={setFocus} />
            <SliderRow icon={<Shield size={16} color={Colors.gold} />} label="Confidence" value={confidence} onChange={setConfidence} />
          </Card>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(300).duration(400)}>
          <Card variant="gradient" shadow="card" style={styles.card}>
            <Text style={styles.cardSectionTitle}>REFLECTION</Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>KEY MISTAKES</Text>
              <TextInput style={[styles.input, styles.textArea]} placeholder="What went wrong that you can learn from?" placeholderTextColor={Colors.textQuaternary} value={mistakes} onChangeText={setMistakes} multiline numberOfLines={3} textAlignVertical="top" />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>MENTAL STATE</Text>
              <TextInput style={[styles.input, styles.textArea]} placeholder="How did you feel mentally during the match?" placeholderTextColor={Colors.textQuaternary} value={mentalState} onChangeText={setMentalState} multiline numberOfLines={3} textAlignVertical="top" />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>NOTES</Text>
              <TextInput style={[styles.input, styles.textArea]} placeholder="Any other reflections..." placeholderTextColor={Colors.textQuaternary} value={notes} onChangeText={setNotes} multiline numberOfLines={3} textAlignVertical="top" />
            </View>
          </Card>
        </Animated.View>

        {error && <Text style={styles.errorText}>{error}</Text>}

        <Button label="Save Review" onPress={submit} loading={saving} iconRight={<ArrowRight size={20} color={Colors.background} />} />
      </ScrollView>
    </ScreenBackground>
  );
}

function SliderRow({ icon, label, value, onChange }: { icon: React.ReactNode; label: string; value: number; onChange: (v: number) => void }) {
  return (
    <View style={styles.sliderRow}>
      <View style={styles.sliderHeader}>
        <View style={styles.sliderIcon}>{icon}</View>
        <Text style={styles.sliderLabel}>{label}</Text>
        <Text style={styles.sliderValue}>{RATING_LABELS[value - 1]}</Text>
      </View>
      <View style={styles.sliderTrack}>
        {[1, 2, 3, 4, 5].map((n) => (
          <TouchableOpacity
            key={n}
            onPress={() => onChange(n)}
            activeOpacity={0.7}
            style={[styles.sliderSegment, n <= value && styles.sliderSegmentActive, n === 1 && styles.sliderSegmentFirst, n === 5 && styles.sliderSegmentLast]}
          >
            <Text style={[styles.sliderSegmentText, n <= value && styles.sliderSegmentTextActive]}>{n}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: Spacing.lg, paddingTop: Spacing.xxxl + 16, paddingBottom: Spacing.sm },
  closeBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  headerTitle: { ...Typography.h2, fontFamily: 'Inter-ExtraBold', color: Colors.textPrimary, fontSize: 18 },
  scroll: { paddingHorizontal: Spacing.lg, paddingBottom: Spacing.xxxl, gap: Spacing.lg },
  intro: { ...Typography.bodySmall, color: Colors.textTertiary, fontFamily: 'Inter-Medium', fontStyle: 'italic', paddingHorizontal: Spacing.xs, marginBottom: Spacing.xs },

  card: { gap: Spacing.md },
  cardSectionTitle: { color: Colors.gold, fontFamily: 'Inter-SemiBold', fontSize: 12, letterSpacing: 1.5, marginBottom: Spacing.xs },
  inputGroup: { gap: Spacing.xs },
  inputLabel: { ...Typography.micro, color: Colors.textTertiary, fontFamily: 'Inter-SemiBold', letterSpacing: 1 },
  input: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 14, color: Colors.textPrimary, fontFamily: 'Inter-Regular', fontSize: 16 },
  textArea: { minHeight: 80, paddingTop: 14, lineHeight: 22 },

  sliderRow: { gap: Spacing.sm },
  sliderHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  sliderIcon: { width: 32, height: 32, borderRadius: 10, backgroundColor: Colors.goldSoft, justifyContent: 'center', alignItems: 'center' },
  sliderLabel: { flex: 1, color: Colors.textSecondary, fontFamily: 'Inter-SemiBold', fontSize: 15 },
  sliderValue: { color: Colors.gold, fontFamily: 'Inter-SemiBold', fontSize: 13 },
  sliderTrack: { flexDirection: 'row', gap: 6, height: 44 },
  sliderSegment: { flex: 1, borderRadius: Radius.sm, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, justifyContent: 'center', alignItems: 'center' },
  sliderSegmentActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  sliderSegmentFirst: { borderTopLeftRadius: Radius.md, borderBottomLeftRadius: Radius.md },
  sliderSegmentLast: { borderTopRightRadius: Radius.md, borderBottomRightRadius: Radius.md },
  sliderSegmentText: { color: Colors.textQuaternary, fontFamily: 'Inter-SemiBold', fontSize: 15 },
  sliderSegmentTextActive: { color: Colors.background, fontFamily: 'Inter-ExtraBold' },

  errorText: { color: Colors.error, fontFamily: 'Inter-Regular', fontSize: 14, textAlign: 'center' },
  savedWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: Spacing.lg, gap: Spacing.md },
  savedIcon: { width: 72, height: 72, borderRadius: 20, backgroundColor: Colors.gold, justifyContent: 'center', alignItems: 'center' },
  savedTitle: { ...Typography.h1, fontFamily: 'Inter-ExtraBold', color: Colors.textPrimary },
  savedSub: { ...Typography.bodySmall, color: Colors.textSecondary, textAlign: 'center', paddingHorizontal: Spacing.lg, lineHeight: 22 },
});
